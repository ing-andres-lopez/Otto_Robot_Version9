                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2951270
HOW TO MAKE A OTTO ROBOT  by Sametk is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Who is Otto?
An interactive robot that anyone can make!
What can Otto do?
Otto walks, dances, makes sounds and avoids obstacles.
Why Is Otto special?
Otto is completely open source, Arduino compatible, 3D printable, and with a social impact mission to create an inclusive environment for all kids.
Otto's differences are in the assembled size (11cm x 7cm x12cm), cleaner integration of components and expressions. Using off the shelf and 3D printed parts, simple electronics connections (almost no welding required), and basic coding skills, you will be able to build your own cute Otto friend in as little as two hours!
Let's make it
And If you want to make this " OTTO ROBOT ", you need 3D Printer parts files and arduino codes. You can find all files below link for downloads.


# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: 200 micron
Infill: %30

# How I Designed This

<iframe src="//www.youtube.com/embed/JRH5YYa0kYA" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/eJmgjNDIGtc" frameborder="0" allowfullscreen></iframe>